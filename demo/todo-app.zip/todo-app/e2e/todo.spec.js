import { expect, test } from '@playwright/test'

test.beforeEach(async ({ page }) => {
  await page.goto('/')
  await page.evaluate(() => localStorage.clear())
  await page.reload()
})

test('adds, completes, deletes, and persists a task', async ({ page }) => {
  const task = 'Write the course'
  const input = page.getByLabel('New task')

  await input.fill(task)
  await page.getByRole('button', { name: 'Add task' }).click()
  await expect(page.getByRole('checkbox', { name: task })).toBeVisible()

  await page.getByRole('checkbox', { name: task }).check()
  await expect(page.getByText(task)).toHaveClass(/done/)
  await page.reload()
  await expect(page.getByRole('checkbox', { name: task })).toBeChecked()

  await page.getByRole('button', { name: `Delete ${task}` }).click()
  await expect(page.getByRole('checkbox', { name: task })).toHaveCount(0)
})
