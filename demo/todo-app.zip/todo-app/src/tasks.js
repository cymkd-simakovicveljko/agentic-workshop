export function addTask(tasks, text, id = crypto.randomUUID()) {
  const title = text.trim()
  return title ? [...tasks, { id, title, done: false }] : tasks
}

export function toggleTask(tasks, id) {
  return tasks.map((task) => task.id === id ? { ...task, done: !task.done } : task)
}

export function deleteTask(tasks, id) {
  return tasks.filter((task) => task.id !== id)
}

function isTaskList(value) {
  return Array.isArray(value) && value.every((task) =>
    typeof task?.id === 'string' && typeof task.title === 'string' && typeof task.done === 'boolean',
  )
}

export function loadTasks(storage) {
  try {
    const tasks = JSON.parse(storage.getItem('todo-app-tasks') ?? '[]')
    return isTaskList(tasks) ? tasks : []
  } catch {
    return []
  }
}

export function saveTasks(tasks, storage) {
  try {
    storage.setItem('todo-app-tasks', JSON.stringify(tasks))
    return true
  } catch {
    return false
  }
}
