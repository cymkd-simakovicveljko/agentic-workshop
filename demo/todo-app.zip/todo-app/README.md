# Todo app

The course's canonical React + Vite example. It deliberately has one screen: add,
complete and delete tasks; the browser persists them with `localStorage`.

## Run it

Use Node.js 22.12 or later.

```sh
npm install
npm run dev
```

Open the URL Vite prints. For browser tests, install Playwright's browser once:

```sh
npx playwright install
```

```sh
npm test
npm run test:e2e
```

## Exercises

`main` is the working baseline. Start an exercise without completing another:

```sh
git switch exercise/remaining-count
git switch -c my-remaining-count
```

Before switching with unfinished work, inspect it and either commit it to your own
branch or use `git stash push -m "my unfinished work"`. Do not reset work you may
need. Each `exercise/<topic>` branch has its starting brief; its matching
`solution/<topic>` branch is a runnable reference.

The app never needs OMP to run. Install OMP and use an authorized provider only
when a lesson asks you to observe or try an agent. Keep provider credentials out
of prompts and repository files; review requested commands and edits before
approving them.
