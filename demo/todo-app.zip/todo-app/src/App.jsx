import { useState } from 'react'
import { addTask, deleteTask, loadTasks, saveTasks, toggleTask } from './tasks.js'

const storage = window.localStorage

export default function App() {
  const [tasks, setTasks] = useState(() => loadTasks(storage))
  const [title, setTitle] = useState('')
  const [inputError, setInputError] = useState('')
  const [storageError, setStorageError] = useState('')

  function changeTasks(nextTasks) {
    setTasks(nextTasks)
    setStorageError(saveTasks(nextTasks, storage) ? '' : 'Changes are only saved in this tab.')
  }

  function submit(event) {
    event.preventDefault()
    const nextTasks = addTask(tasks, title)
    if (nextTasks === tasks) {
      setInputError('Enter a task first.')
      return
    }
    changeTasks(nextTasks)
    setTitle('')
    setInputError('')
  }

  return (
    <main>
      <h1>Tasks</h1>
      <form onSubmit={submit}>
        <label htmlFor="new-task">New task</label>
        <div className="new-task">
          <input
            id="new-task"
            value={title}
            onChange={(event) => { setTitle(event.target.value); setInputError('') }}
            aria-describedby={inputError ? 'task-error' : undefined}
          />
          <button type="submit">Add task</button>
        </div>
        {inputError && <p id="task-error" role="alert">{inputError}</p>}
      </form>
      {storageError && <p role="status">{storageError}</p>}
      <ul aria-label="Task list">
        {tasks.map((task) => (
          <li key={task.id}>
            <label>
              <input
                type="checkbox"
                checked={task.done}
                onChange={() => changeTasks(toggleTask(tasks, task.id))}
              />
              <span className={task.done ? 'done' : ''}>{task.title}</span>
            </label>
            <button type="button" aria-label={`Delete ${task.title}`} onClick={() => changeTasks(deleteTask(tasks, task.id))}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </main>
  )
}
