import { describe, expect, it } from 'vitest'
import { addTask, deleteTask, loadTasks, saveTasks, toggleTask } from './tasks.js'

describe('tasks', () => {
  it('rejects a blank task', () => {
    const tasks = [{ id: 'first', title: 'Keep this', done: false }]
    expect(addTask(tasks, '   ')).toBe(tasks)
  })

  it('changes only the intended task', () => {
    const tasks = [
      { id: 'first', title: 'First', done: false },
      { id: 'second', title: 'Second', done: false },
    ]
    expect(toggleTask(tasks, 'second')).toEqual([
      { id: 'first', title: 'First', done: false },
      { id: 'second', title: 'Second', done: true },
    ])
  })

  it('adds trimmed tasks and deletes by identity', () => {
    const tasks = addTask([], '  Write tests  ', 'new')
    expect(tasks).toEqual([{ id: 'new', title: 'Write tests', done: false }])
    expect(deleteTask(tasks, 'new')).toEqual([])
  })

  it('loads valid storage and reports a failed save', () => {
    const storage = new Map()
    storage.getItem = storage.get.bind(storage)
    storage.setItem = storage.set.bind(storage)
    const tasks = [{ id: 'first', title: 'Persist me', done: false }]
    expect(saveTasks(tasks, storage)).toBe(true)
    expect(loadTasks(storage)).toEqual(tasks)
    expect(saveTasks(tasks, { setItem() { throw new Error('blocked') } })).toBe(false)
  })
})
